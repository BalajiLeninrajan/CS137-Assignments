#include <stdbool.h>
#include <assert.h>
#include <stdio.h>

typedef struct FlexData
{
    bool isInt;
    int value_int;
    double value_double;
} FlexData;

FlexData flexDivide(FlexData a, FlexData b)
{
    if (a.isInt && b.isInt)
    {
        FlexData res = {true, a.value_int / b.value_int, 0};
        return res;
    }
    else if (a.isInt)
    {
        FlexData res = {false, 0, a.value_int / b.value_double};
        return res;
    }
    else if (b.isInt)
    {
        FlexData res = {false, 0, a.value_double / b.value_int};
        return res;
    }
    else
    {
        FlexData res = {false, 0, a.value_double / b.value_double};
        return res;
    }
}